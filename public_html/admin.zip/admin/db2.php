<?php
    $host="localhost";
    $user="id19072847_root";
    $pass="60(~kf#!cO\FtE}G";
    $db='id19072847_funko_shop';
?>
